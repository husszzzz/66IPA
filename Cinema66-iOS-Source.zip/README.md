# Cinema 66 iOS Web App

Website: https://cinema66.pages.dev/

The app uses Apple's WKWebView to display the website in a native iOS shell.

Included:
- Animated Cinema 66 splash screen
- Refresh button
- Back and forward buttons
- JavaScript
- Inline media playback
- Loading and connection-error states
- XcodeGen project.yml
- GitHub Actions build.yml
- Unsigned IPA artifact

Upload the contents of this folder to a GitHub repository, then run:
Actions -> Build Cinema 66 IPA -> Run workflow

import SwiftUI
import WebKit

final class WebViewModel: NSObject, ObservableObject {
    @Published var isLoading = true
    @Published var hasError = false
    @Published var canGoBack = false
    @Published var canGoForward = false

    weak var webView: WKWebView?

    private var loadToken = UUID()

    func reload() {
        hasError = false
        isLoading = true
        webView?.reloadFromOrigin()
        startTimeoutWatchdog()
    }

    /// لو الصفحة ضلت "تحمّل" أكثر من 15 ثانية بدون أي رد
    /// (لا نجاح ولا فشل من WKWebView)، نجبرها تطلع كخطأ
    /// بدل ما تضل عالقة بالسبينر للأبد.
    func startTimeoutWatchdog(seconds: UInt64 = 15) {
        let token = UUID()
        loadToken = token

        Task { @MainActor in
            try? await Task.sleep(nanoseconds: seconds * 1_000_000_000)

            guard self.loadToken == token else { return }

            if self.isLoading {
                self.isLoading = false
                self.hasError = true
                self.webView?.stopLoading()
            }
        }
    }

    func goBack() { webView?.goBack() }
    func goForward() { webView?.goForward() }

    func updateNavigationState(_ webView: WKWebView) {
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
    }
}

struct WebView: UIViewRepresentable {
    let url: URL
    @ObservedObject var model: WebViewModel

    func makeCoordinator() -> Coordinator {
        Coordinator(model: model)
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true

        if #available(iOS 10.0, *) {
            configuration.mediaTypesRequiringUserActionForPlayback = []
        }

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.alwaysBounceVertical = true
        webView.scrollView.bounces = true
        webView.backgroundColor = .systemBackground

        model.webView = webView

        webView.load(URLRequest(
            url: url,
            cachePolicy: .useProtocolCachePolicy,
            timeoutInterval: 30
        ))

        model.startTimeoutWatchdog()

        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        model.updateNavigationState(webView)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let model: WebViewModel

        init(model: WebViewModel) {
            self.model = model
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation?) {
            DispatchQueue.main.async {
                self.model.isLoading = true
                self.model.hasError = false
                self.model.updateNavigationState(webView)
                self.model.startTimeoutWatchdog()
            }
        }

        func webView(_ webView: WKWebView, didCommit navigation: WKNavigation?) {
            DispatchQueue.main.async {
                self.model.isLoading = false
                self.model.updateNavigationState(webView)
            }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation?) {
            DispatchQueue.main.async {
                self.model.isLoading = false
                self.model.hasError = false
                self.model.updateNavigationState(webView)
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation?, withError error: Error) {
            DispatchQueue.main.async {
                self.model.isLoading = false
                self.model.hasError = true
                self.model.updateNavigationState(webView)
            }
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation?, withError error: Error) {
            DispatchQueue.main.async {
                self.model.isLoading = false
                self.model.hasError = true
                self.model.updateNavigationState(webView)
            }
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let targetURL = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }

            let scheme = targetURL.scheme?.lowercased() ?? ""

            if scheme == "http" || scheme == "https" {
                decisionHandler(.allow)
            } else if UIApplication.shared.canOpenURL(targetURL) {
                UIApplication.shared.open(targetURL)
                decisionHandler(.cancel)
            } else {
                decisionHandler(.cancel)
            }
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            if navigationAction.targetFrame == nil {
                webView.load(navigationAction.request)
            }
            return nil
        }
    }
}

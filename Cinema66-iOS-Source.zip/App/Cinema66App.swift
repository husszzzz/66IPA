import SwiftUI

@main
struct Cinema66App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

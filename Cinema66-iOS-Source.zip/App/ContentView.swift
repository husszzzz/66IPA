import SwiftUI

struct ContentView: View {
    @StateObject private var webViewModel = WebViewModel()
    @State private var showSplash = true

    private let siteURL = URL(string: "https://cinema66.pages.dev/")!

    var body: some View {
        ZStack {
            WebView(url: siteURL, model: webViewModel)
                .ignoresSafeArea()

            VStack {
                Spacer()
                HStack(spacing: 10) {
                    Button { webViewModel.goBack() } label: {
                        Image(systemName: "chevron.left")
                    }
                    .disabled(!webViewModel.canGoBack)

                    Button { webViewModel.reload() } label: {
                        Image(systemName: "arrow.clockwise")
                    }

                    Button { webViewModel.goForward() } label: {
                        Image(systemName: "chevron.right")
                    }
                    .disabled(!webViewModel.canGoForward)
                }
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white)
                .padding(.horizontal, 16)
                .padding(.vertical, 11)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(.white.opacity(0.18), lineWidth: 1))
                .shadow(radius: 12)
                .padding(.bottom, 12)
            }
            .opacity(showSplash ? 0 : 1)

            if webViewModel.isLoading && !showSplash {
                VStack(spacing: 10) {
                    ProgressView().tint(.white)
                    Text("جاري التحميل...")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(.white.opacity(0.9))
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 13)
                .background(.black.opacity(0.65))
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }

            if webViewModel.hasError && !showSplash {
                VStack(spacing: 14) {
                    Image(systemName: "wifi.exclamationmark")
                        .font(.system(size: 40))
                    Text("تعذر الاتصال")
                        .font(.system(size: 21, weight: .bold))
                    Text("تحقق من اتصال الإنترنت ثم حاول مرة أخرى.")
                        .font(.system(size: 14))
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    Button {
                        webViewModel.reload()
                    } label: {
                        Label("إعادة المحاولة", systemImage: "arrow.clockwise")
                            .font(.system(size: 15, weight: .semibold))
                            .padding(.horizontal, 20)
                            .padding(.vertical, 11)
                            .foregroundStyle(.white)
                            .background(Color(red: 0.45, green: 0.16, blue: 0.82))
                            .clipShape(Capsule())
                    }
                }
                .padding(28)
                .background(.regularMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .shadow(radius: 20)
                .padding(24)
            }

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(10)
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
                withAnimation(.easeInOut(duration: 0.45)) {
                    showSplash = false
                }
            }
        }
    }
}

struct SplashView: View {
    @State private var pulse = false
    @State private var logoScale = 0.82

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.04, green: 0.02, blue: 0.10),
                    Color(red: 0.17, green: 0.03, blue: 0.30),
                    Color(red: 0.04, green: 0.01, blue: 0.08)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            Circle()
                .fill(Color.purple.opacity(0.22))
                .frame(width: 330, height: 330)
                .blur(radius: 55)
                .scaleEffect(pulse ? 1.12 : 0.92)
                .offset(x: 90, y: -250)

            Circle()
                .fill(Color.blue.opacity(0.14))
                .frame(width: 280, height: 280)
                .blur(radius: 60)
                .scaleEffect(pulse ? 0.92 : 1.08)
                .offset(x: -130, y: 270)

            VStack(spacing: 18) {
                ZStack {
                    Circle()
                        .fill(.white.opacity(0.08))
                        .frame(width: 116, height: 116)
                        .overlay(Circle().stroke(.white.opacity(0.16), lineWidth: 1))
                        .shadow(color: .purple.opacity(0.45), radius: 30)

                    Image(systemName: "film.stack.fill")
                        .font(.system(size: 48, weight: .bold))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.white, Color(red: 0.72, green: 0.45, blue: 1)],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                }
                .scaleEffect(logoScale)

                VStack(spacing: 6) {
                    Text("CINEMA 66")
                        .font(.system(size: 31, weight: .black, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(.white)

                    Text("استمتع بالمشاهدة")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.white.opacity(0.65))
                }

                ProgressView()
                    .tint(.white)
                    .scaleEffect(0.9)
                    .padding(.top, 10)
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.4).repeatForever(autoreverses: true)) {
                pulse = true
            }
            withAnimation(.spring(response: 0.75, dampingFraction: 0.7)) {
                logoScale = 1
            }
        }
    }
}

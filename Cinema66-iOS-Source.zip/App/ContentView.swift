import SwiftUI

struct ContentView: View {
    @StateObject private var webViewModel = WebViewModel()

    private let siteURL = URL(string: "https://cinema66.pages.dev/")!

    var body: some View {
        ZStack {
            WebView(url: siteURL, model: webViewModel)
                .ignoresSafeArea()

            VStack {
                Spacer()
                HStack(spacing: 10) {
                    Button { webViewModel.goBack() } label: {
                        Image(systemName: "chevron.left")
                    }
                    .disabled(!webViewModel.canGoBack)

                    Button { webViewModel.reload() } label: {
                        Image(systemName: "arrow.clockwise")
                    }

                    Button { webViewModel.goForward() } label: {
                        Image(systemName: "chevron.right")
                    }
                    .disabled(!webViewModel.canGoForward)
                }
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white)
                .padding(.horizontal, 16)
                .padding(.vertical, 11)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(.white.opacity(0.18), lineWidth: 1))
                .shadow(radius: 12)
                .padding(.bottom, 12)
            }

            if webViewModel.isLoading {
                VStack(spacing: 10) {
                    ProgressView().tint(.white)
                    Text("جاري التحميل...")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(.white.opacity(0.9))
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 13)
                .background(.black.opacity(0.65))
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }

            if webViewModel.hasError {
                VStack(spacing: 14) {
                    Image(systemName: "wifi.exclamationmark")
                        .font(.system(size: 40))
                    Text("تعذر الاتصال")
                        .font(.system(size: 21, weight: .bold))
                    Text("تحقق من اتصال الإنترنت ثم حاول مرة أخرى.")
                        .font(.system(size: 14))
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    Button {
                        webViewModel.reload()
                    } label: {
                        Label("إعادة المحاولة", systemImage: "arrow.clockwise")
                            .font(.system(size: 15, weight: .semibold))
                            .padding(.horizontal, 20)
                            .padding(.vertical, 11)
                            .foregroundStyle(.white)
                            .background(Color(red: 0.45, green: 0.16, blue: 0.82))
                            .clipShape(Capsule())
                    }
                }
                .padding(28)
                .background(.regularMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .shadow(radius: 20)
                .padding(24)
            }
        }
        .preferredColorScheme(.dark)
    }
}
